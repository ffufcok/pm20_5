from pm20_5.questions import q1, q2, q3
from pm20_5 import q1_1_2.png
