from pm20.questions import q1, q2, q3
